package com.example;

import com.example.client.FxClient;
import com.example.client.PromoClient;
import com.example.model.PointsResponse;
import com.example.service.PointsService;
import com.example.service.RequestValidator;

import io.vertx.core.Vertx;
import io.vertx.junit5.VertxExtension;
import io.vertx.junit5.VertxTestContext;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static com.github.tomakehurst.wiremock.client.WireMock.*;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;

@ExtendWith(VertxExtension.class)
public class PointsServiceComponentTest {

    static WireMockServer fxMock;
    static WireMockServer promoMock;

    @BeforeAll
    static void setupAll() {
        fxMock = new WireMockServer(WireMockConfiguration.options().dynamicPort());
        promoMock = new WireMockServer(WireMockConfiguration.options().dynamicPort());
        fxMock.start();
        promoMock.start();
    }

    @AfterAll
    static void teardownAll() {
        fxMock.stop();
        promoMock.stop();
    }

    @Test
    void happy_path(Vertx vertx, VertxTestContext testContext) {
        // Stub FX mock
        fxMock.stubFor(get(urlPathEqualTo("/fx"))
            .withQueryParam("from", equalTo("USD"))
            .withQueryParam("to", equalTo("LOCAL"))
            .willReturn(okJson("{\"rate\":3.5}")));

        // Stub promo mock
        promoMock.stubFor(get(urlPathMatching("/promo/SUMMER25"))
            .willReturn(okJson("{\"type\":\"PERCENT\",\"value\":20,\"expiresInDays\":5}")));

        // Create clients for PointsService
        FxClient fxClient = new FxClient(vertx, "http://localhost:" + fxMock.port());
        PromoClient promoClient = new PromoClient(vertx, "http://localhost:" + promoMock.port());

        PointsService pointsService =
                new PointsService(fxClient, promoClient, new RequestValidator());

        // Build request payload
        var req = new io.vertx.core.json.JsonObject()
                .put("fareAmount", 100)
                .put("currency", "USD")
                .put("promoCode", "SUMMER25")
                .put("tier", "GOLD");

        // Call service
        pointsService.quote(req).onComplete(ar -> {
            if (ar.succeeded()) {
                PointsResponse resp = ar.result();

                // Basic validations
                testContext.verify(() -> {
                    org.assertj.core.api.Assertions.assertThat(resp.totalPoints).isGreaterThan(0);
                });
                testContext.completeNow();
            } else {
                testContext.failNow(ar.cause());
            }
        });
    }
}
