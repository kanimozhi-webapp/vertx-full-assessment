package com.example.model;

import io.vertx.core.json.JsonObject;
import java.util.ArrayList;
import java.util.List;

public class PointsResponse {
    public int basePoints;
    public int tierBonus;
    public int promoBonus;
    public int totalPoints;
    public double effectiveFxRate;
    public List<String> warnings = new ArrayList<>();

    // Return a JsonObject representation
    public JsonObject toJson() {
        JsonObject j = new JsonObject();
        j.put("basePoints", basePoints);
        j.put("tierBonus", tierBonus);
        j.put("promoBonus", promoBonus);
        j.put("totalPoints", totalPoints);
        j.put("effectiveFxRate", effectiveFxRate);
        j.put("warnings", warnings);
        return j;
    }

    // Return an encoded JSON string safe to pass to HttpServerResponse.end(...)
    public String encode() {
        return toJson().encode();
    }
}
