package com.example.service;

import com.example.client.FxClient;
import com.example.client.PromoClient;
import com.example.model.PointsResponse;
import io.vertx.core.Future;
import io.vertx.core.Promise;
import io.vertx.core.json.JsonObject;

public class PointsService {

    private final FxClient fxClient;
    private final PromoClient promoClient;
    private final RequestValidator validator;
    private static final int CAP = 50000;

    public PointsService(FxClient fxClient, PromoClient promoClient, RequestValidator validator) {
        this.fxClient = fxClient;
        this.promoClient = promoClient;
        this.validator = validator;
    }

    public Future<PointsResponse> quote(JsonObject req) {
        try {
            validator.validate(req);
        } catch (IllegalArgumentException ex) {
            return Future.failedFuture(ex);
        }

        Promise<PointsResponse> p = Promise.promise();
        String currency = req.getString("currency");
        double fare = req.getDouble("fareAmount");
        String tier = req.getString("customerTier", "REGULAR");
        String promoCode = req.getString("promoCode", null);

        fxClient.getRateWithRetries(currency, 3).onFailure(p::fail).onSuccess(rate -> {
            double converted = fare * rate;
            int basePoints = (int) Math.floor(converted);
            int tierBonus = tierMultiplier(tier, basePoints);
            PointsResponse resp = new PointsResponse();
            resp.basePoints = basePoints;
            resp.tierBonus = tierBonus;
            resp.effectiveFxRate = rate;

            // call promo but don't fail overall if promo unavailable or timeout
            promoClient.fetchPromo(promoCode, 500)
                .onSuccess(json -> {
                    int promoBonus = calculatePromoBonus(json, basePoints);
                    resp.promoBonus = promoBonus;
                    if (json.getInteger("expiresInDays", 99) < 3) resp.warnings.add("PROMO_EXPIRES_SOON");
                    finalizeResponse(resp, p);
                })
                .onFailure(err -> {
                    resp.promoBonus = 0;
                    resp.warnings.add("PROMO_UNAVAILABLE");
                    finalizeResponse(resp, p);
                });
        });

        return p.future();
    }

    private void finalizeResponse(PointsResponse resp, Promise<PointsResponse> p) {
        int sum = resp.basePoints + resp.tierBonus + resp.promoBonus;
        resp.totalPoints = Math.min(sum, CAP);
        p.complete(resp);
    }

    private int calculatePromoBonus(JsonObject json, int basePoints) {
        String type = json.getString("type", "FIXED");
        int value = json.getInteger("value", 0);
        if ("PERCENT".equalsIgnoreCase(type)) {
            return (int) Math.floor(basePoints * (value / 100.0));
        } else {
            return value;
        }
    }

    private int tierMultiplier(String tier, int base) {
        switch (tier.toUpperCase()) {
            case "GOLD": return (int) Math.floor(base * 0.15);
            case "SILVER": return (int) Math.floor(base * 0.10);
            default: return 0;
        }
    }
}
