package com.example.service;

import io.vertx.core.json.JsonObject;

public class RequestValidator {

    public void validate(JsonObject req) {
        if (!req.containsKey("fareAmount") || req.getDouble("fareAmount") == null) {
            throw new IllegalArgumentException("fareAmount is required");
        }
        double fare = req.getDouble("fareAmount");
        if (fare <= 0) throw new IllegalArgumentException("fareAmount must be > 0");

        if (!req.containsKey("currency")) throw new IllegalArgumentException("currency is required");
        String currency = req.getString("currency");
        if (currency.length() != 3) throw new IllegalArgumentException("currency must be 3-letter code");
    }
}
