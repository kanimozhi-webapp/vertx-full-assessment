package com.example.client;

import io.vertx.core.Future;
import io.vertx.core.json.JsonObject;

public class FxClient {

    public FxClient(io.vertx.core.Vertx vertx, String base) {
        // base no longer used (mock implementation)
    }

    // ---- SIMPLE MOCK FX RATE ----
    public Future<JsonObject> fetchRate(String currency) {
        JsonObject mock = new JsonObject()
                .put("rate", 1.35);

        return Future.succeededFuture(mock);
    }

    // ---- COMPATIBILITY METHOD (required by PointsService) ----
    public Future<Double> getRateWithRetries(String currency, int retries) {

        // Always succeed with mock rate
        return Future.succeededFuture(1.35);

        // If you want real retry logic in future, expand here
    }
}
