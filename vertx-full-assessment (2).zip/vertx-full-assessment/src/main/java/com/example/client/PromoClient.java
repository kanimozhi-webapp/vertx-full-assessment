package com.example.client;

import io.vertx.core.Future;
import io.vertx.core.json.JsonObject;

public class PromoClient {

    public PromoClient(io.vertx.core.Vertx vertx, String base) {
        // base ignored – using internal mock promo
    }

    // Always return SUMMER25 promo
    public Future<JsonObject> fetchPromo(String promoCode, long timeoutMs) {

        JsonObject promo = new JsonObject()
                .put("type", "PERCENT")
                .put("value", 20)
                .put("expiresInDays", 5);

        return Future.succeededFuture(promo);
    }
}
