package com.example;

import com.example.client.FxClient;
import com.example.client.PromoClient;
import com.example.model.PointsResponse;
import com.example.service.PointsService;
import com.example.service.RequestValidator;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.ext.web.Router;
import io.vertx.core.json.JsonObject;

public class MainVerticle extends AbstractVerticle {

    private PointsService pointsService;

    @Override
    public void start(Promise<Void> startPromise) {

        String fxBase = System.getenv().getOrDefault("FX_BASE", "http://localhost:8089");
        String promoBase = System.getenv().getOrDefault("PROMO_BASE", "http://localhost:8090");

        FxClient fxClient = new FxClient(vertx, fxBase);
        PromoClient promoClient = new PromoClient(vertx, promoBase);
        pointsService = new PointsService(fxClient, promoClient, new RequestValidator());

        Router router = Router.router(vertx);

        router.post("/v1/points/quote").handler(ctx -> {
            ctx.request().bodyHandler(buffer -> {
                JsonObject body = buffer.toJsonObject();

                pointsService.quote(body)
                    .onSuccess(resp -> {
                        ctx.response()
                           .putHeader("content-type", "application/json")
                           .setStatusCode(200)
                           .end(resp.encode());   // resp.encode() now returns a String
                    })
                    .onFailure(err -> {
                        if (err instanceof IllegalArgumentException) {
                            ctx.response()
                               .setStatusCode(400)
                               .end(new JsonObject().put("error", err.getMessage()).encode());
                        } else {
                            ctx.response()
                               .setStatusCode(502)
                               .end(new JsonObject().put("error", "upstream failure").encode());
                        }
                    });
            });
        });

        vertx.createHttpServer()
             .requestHandler(router)
             .listen(8080, http -> {
                 if (http.succeeded()) {
                     System.out.println("HTTP server started on port 8080");
                     startPromise.complete();
                 } else {
                     startPromise.fail(http.cause());
                 }
             });
    }
}
